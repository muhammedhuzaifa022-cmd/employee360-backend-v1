"""
WHO MAY DO WHAT - the single place for role and department rules.

  Admin     : the whole company.
  Team lead : only their OWN department (and only employees in it).
  Employee  : only themselves.

Every later module (users, tasks, leave, analytics...) uses these functions,
so the rules are the same for the web app and the mobile apps.
"""
from sqlalchemy import ColumnElement, false, true

from app.models import User
from app.models.enums import UserRole


def is_admin(user: User) -> bool:
    return user.role == UserRole.ADMIN


def is_team_lead(user: User) -> bool:
    return user.role == UserRole.TEAMLEAD


def is_manager(user: User) -> bool:
    """Admins and team leads (the frontend's canManage())."""
    return user.role in (UserRole.ADMIN, UserRole.TEAMLEAD)


def same_department(a: User, b: User) -> bool:
    return a.department_id is not None and a.department_id == b.department_id


# ---------------- people ----------------
def can_view_user(actor: User, target: User) -> bool:
    """Profile / Team page / performance of `target`."""
    if actor.id == target.id or is_admin(actor):
        return True
    if is_team_lead(actor):
        return same_department(actor, target)
    return False


def can_manage_user(actor: User, target: User) -> bool:
    """Approve their work and leave, change their deadlines, see their workload."""
    if actor.id == target.id:
        return False  # nobody approves their own work or leave
    if is_admin(actor):
        return True
    if is_team_lead(actor):
        return same_department(actor, target) and target.role == UserRole.EMPLOYEE
    return False


def can_assign_task_to(actor: User, target: User) -> bool:
    """Frontend rule: tasks go to active non-admin users."""
    if not target.is_active or target.role == UserRole.ADMIN:
        return False
    if is_admin(actor):
        return True
    if is_team_lead(actor):
        return target.id == actor.id or (same_department(actor, target)
                                         and target.role == UserRole.EMPLOYEE)
    return False


def can_decide_leave(actor: User, requester: User) -> bool:
    """
    Employee leave  -> team leads of that department, or any admin.
    Team lead leave -> admins only.
    Admin leave     -> another admin.
    Nobody decides their own leave.
    """
    return can_manage_user(actor, requester)


def can_administer_accounts(actor: User) -> bool:
    """Add employees, activate/deactivate, change roles."""
    return is_admin(actor)


# ---------------- database filters ----------------
def visible_users_condition(actor: User) -> ColumnElement[bool]:
    """WHERE-clause: which users `actor` may see in lists."""
    if is_admin(actor):
        return true()
    if is_team_lead(actor):
        if actor.department_id is None:
            return User.id == actor.id
        return User.department_id == actor.department_id
    return User.id == actor.id


def managed_users_condition(actor: User) -> ColumnElement[bool]:
    """WHERE-clause: users whose work/leave `actor` manages."""
    if is_admin(actor):
        return User.id != actor.id
    if is_team_lead(actor) and actor.department_id is not None:
        return (User.department_id == actor.department_id) & (User.role == UserRole.EMPLOYEE)
    return false()
