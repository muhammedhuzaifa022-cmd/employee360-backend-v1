"""
Joins every v1 router together under /api/v1.
New modules (users, tasks...) are added here one by one.
"""
from fastapi import APIRouter

from app.api.v1 import auth, devices, system

api_router = APIRouter()
api_router.include_router(system.router)
api_router.include_router(auth.router)
api_router.include_router(devices.router)
