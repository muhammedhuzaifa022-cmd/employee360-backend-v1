"""User-related response shapes (more are added in Module 5)."""
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict

from app.models.enums import UserRole


class DepartmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str


class UserMe(BaseModel):
    """The logged-in user - used for the sidebar, top bar and role checks in apps."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    full_name: str
    email: str
    role: UserRole
    designation: str
    department: DepartmentOut | None
    is_active: bool
    joined_on: date
    last_login_at: datetime | None
    created_at: datetime
