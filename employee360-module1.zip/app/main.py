"""
The starting point of the backend.

Creates the FastAPI app, adds security settings (CORS), the error
format, all API routes under /api/v1, and serves the web frontend.
Run with:  uvicorn app.main:app --reload
"""
import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.exceptions import register_exception_handlers
from app.schemas.common import COMMON_ERROR_RESPONSES

logging.basicConfig(level=logging.DEBUG if settings.DEBUG else logging.INFO,
                    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"

API_DESCRIPTION = """
Common backend for the **Employee360** web app and the future Android/iOS apps.

* All endpoints live under **`/api/v1`**.
* Authentication: send `Authorization: Bearer <access_token>` (from Module 3).
* Dates: `YYYY-MM-DD`. Timestamps: ISO-8601 in UTC.
* Every error has the shape `{"detail": "...", "code": "...", "fields": {...}}`.
"""


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.API_VERSION,
        description=API_DESCRIPTION,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        swagger_ui_parameters={"persistAuthorization": True},
    )

    # Browsers only: which websites may call this API.
    if settings.CORS_ORIGINS:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.CORS_ORIGINS,
            allow_credentials=False,          # we use Bearer tokens, not cookies
            allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
            allow_headers=["Authorization", "Content-Type", "Accept", "X-Requested-With"],
            max_age=600,
        )

    register_exception_handlers(app)
    app.include_router(api_router, prefix=settings.API_V1_PREFIX,
                       responses=COMMON_ERROR_RESPONSES)

    # Serve the existing web frontend at http://127.0.0.1:8000/app/
    if (FRONTEND_DIR / "index.html").exists():
        app.mount("/app", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")

    @app.get("/", include_in_schema=False)
    def root():
        return RedirectResponse(url="/docs")

    return app


app = create_app()
