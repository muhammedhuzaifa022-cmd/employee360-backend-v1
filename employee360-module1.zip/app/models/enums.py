"""
Fixed lists of allowed values.

The text values are EXACTLY the same as in the frontend
(for example "Submitted for Review"), so the web page needs no changes.
"""
from enum import Enum


class UserRole(str, Enum):
    ADMIN = "admin"
    TEAMLEAD = "teamlead"
    EMPLOYEE = "employee"


class TaskStatus(str, Enum):
    NOT_STARTED = "Not Started"
    IN_PROGRESS = "In Progress"
    SUBMITTED = "Submitted for Review"
    COMPLETED = "Completed"
    DELAYED = "Delayed"
    ON_HOLD = "On Hold"


# Statuses an assignee may set on their own task (the frontend dropdown)
EMPLOYEE_SETTABLE_STATUSES = [
    TaskStatus.NOT_STARTED,
    TaskStatus.IN_PROGRESS,
    TaskStatus.ON_HOLD,
    TaskStatus.DELAYED,
]


class Priority(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class LeaveType(str, Enum):
    ANNUAL = "Annual"
    SICK = "Sick"
    CASUAL = "Casual"
    UNPAID = "Unpaid"


class LeaveStatus(str, Enum):
    PENDING = "Pending"
    APPROVED = "Approved"
    REJECTED = "Rejected"
    CANCELLED = "Cancelled"


class Platform(str, Enum):
    WEB = "web"
    ANDROID = "android"
    IOS = "ios"
