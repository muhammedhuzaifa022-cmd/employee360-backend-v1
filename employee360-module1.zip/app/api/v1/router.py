"""
Joins every v1 router together under /api/v1.
New modules (auth, users, tasks...) are added here one by one.
"""
from fastapi import APIRouter

from app.api.v1 import system

api_router = APIRouter()
api_router.include_router(system.router)
